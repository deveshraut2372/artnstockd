package com.zplus.ArtnStockMongoDB.dto.req;

import lombok.Data;

@Data
public class CheckFileReq {

    private String userId;

    private String id;

    private String type;

}
