package com.zplus.ArtnStockMongoDB.dto.res;

import lombok.Data;

@Data
public class GeoStateName {

    private String geonameId;
    private String name;


}
