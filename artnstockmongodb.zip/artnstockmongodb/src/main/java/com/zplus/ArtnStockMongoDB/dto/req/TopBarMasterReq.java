package com.zplus.ArtnStockMongoDB.dto.req;


import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class TopBarMasterReq {

    private String topBarId;

    private String link1;

    private String link2;

    private String link3;


}
