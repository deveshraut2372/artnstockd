package com.zplus.ArtnStockMongoDB.dto.res;

import lombok.Data;

import java.util.List;

@Data
public class GeoNameResponse {

    List<GeoName> countries;

}
