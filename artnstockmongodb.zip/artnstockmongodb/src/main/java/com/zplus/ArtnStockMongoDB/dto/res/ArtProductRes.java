package com.zplus.ArtnStockMongoDB.dto.res;

import java.util.Date;
import java.util.List;

public class ArtProductRes {

    private String artProductRes;

    private String artProductName;

    private String image;

    private String status;

    private String artProductNo;

    private Date submittedDate;

    private Date reviewData;

    private Date approveDate;

    private Date updatedDate;

    private List<String> typeOfContent;

    private List<String> keywords;

    private String type;



}
