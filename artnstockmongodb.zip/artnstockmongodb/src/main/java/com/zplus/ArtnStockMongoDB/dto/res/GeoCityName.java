package com.zplus.ArtnStockMongoDB.dto.res;

import lombok.Data;

@Data
public class GeoCityName {

    private String geonameId;
    private String name;
}
