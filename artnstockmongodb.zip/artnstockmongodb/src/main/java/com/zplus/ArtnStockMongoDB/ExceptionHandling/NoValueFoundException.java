package com.zplus.ArtnStockMongoDB.ExceptionHandling;


public class NoValueFoundException extends Exception{


   public NoValueFoundException(String msg)
    {
        super(msg);
    }
}
