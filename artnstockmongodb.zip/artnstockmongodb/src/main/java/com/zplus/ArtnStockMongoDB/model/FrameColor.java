package com.zplus.ArtnStockMongoDB.model;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class FrameColor {
    private String colorName;
    private String colorCode;
    private String price;


}
