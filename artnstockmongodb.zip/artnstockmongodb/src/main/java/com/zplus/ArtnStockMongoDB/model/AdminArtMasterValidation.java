package com.zplus.ArtnStockMongoDB.model;

import org.springframework.data.mongodb.core.mapping.Document;

//@Document(collection = "Admin_Art_Master_Validation")
//public class AdminArtMasterValidation {
//
//
//}
