package com.zplus.ArtnStockMongoDB.dto.res;

import lombok.Data;

@Data
public class CollectionCountRes {

    private Integer CollectionCounts;

    private Integer collectionsFileCounts;

}
