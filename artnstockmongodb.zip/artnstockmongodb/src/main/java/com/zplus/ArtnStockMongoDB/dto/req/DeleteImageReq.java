package com.zplus.ArtnStockMongoDB.dto.req;

import lombok.Data;

@Data
public class DeleteImageReq {

    private String draftId;
    private String imageId;

}
