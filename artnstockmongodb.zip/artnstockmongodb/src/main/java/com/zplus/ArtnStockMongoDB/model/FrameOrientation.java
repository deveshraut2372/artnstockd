package com.zplus.ArtnStockMongoDB.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter@Setter@ToString
public class FrameOrientation {

    private String orientationType;
    private String height;
    private String width;
}