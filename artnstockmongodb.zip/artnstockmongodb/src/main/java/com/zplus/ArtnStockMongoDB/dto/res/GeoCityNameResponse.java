package com.zplus.ArtnStockMongoDB.dto.res;

import lombok.Data;

import java.util.List;

@Data
public class GeoCityNameResponse {

    List<GeoCityName> cityNameList;

}
