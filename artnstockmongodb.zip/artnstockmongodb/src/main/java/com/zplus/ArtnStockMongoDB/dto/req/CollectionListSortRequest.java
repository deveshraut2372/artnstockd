package com.zplus.ArtnStockMongoDB.dto.req;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CollectionListSortRequest {
//    private String order;
    private String collectionId;
//    private String searchKey;
}
