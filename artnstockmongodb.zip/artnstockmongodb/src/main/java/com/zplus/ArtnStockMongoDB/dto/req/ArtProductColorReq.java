package com.zplus.ArtnStockMongoDB.dto.req;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ArtProductColorReq {

    private String productColorId;

    private String productImage;

//    private List<ArtSizeAndPrice> artSizeAndPriceList;

}
