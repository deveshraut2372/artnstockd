package com.zplus.ArtnStockMongoDB.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LanguagePreference {

    private String languageCome;
}
