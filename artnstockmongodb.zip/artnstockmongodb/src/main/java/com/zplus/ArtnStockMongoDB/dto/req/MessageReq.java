package com.zplus.ArtnStockMongoDB.dto.req;

import lombok.Data;

@Data
public class MessageReq {

    private String notificationId;

}
