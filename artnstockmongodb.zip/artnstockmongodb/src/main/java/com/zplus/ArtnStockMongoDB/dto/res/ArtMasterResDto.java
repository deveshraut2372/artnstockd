package com.zplus.ArtnStockMongoDB.dto.res;

public class ArtMasterResDto {


}
