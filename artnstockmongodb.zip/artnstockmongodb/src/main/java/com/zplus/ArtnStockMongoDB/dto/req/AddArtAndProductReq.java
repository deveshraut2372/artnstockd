package com.zplus.ArtnStockMongoDB.dto.req;

import lombok.Data;

@Data
public class AddArtAndProductReq {

    private String id;

    private String type;


}
