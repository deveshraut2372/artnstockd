package com.zplus.ArtnStockMongoDB.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeleteAccount {

    private String deleteAccountMsg;

}
