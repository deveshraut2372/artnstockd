package com.zplus.ArtnStockMongoDB.dto.res;

import lombok.Getter;
import lombok.Setter;

@Getter@Setter
public class DisplayNameResponse {
    private Boolean flag;
    private String msg;
}
