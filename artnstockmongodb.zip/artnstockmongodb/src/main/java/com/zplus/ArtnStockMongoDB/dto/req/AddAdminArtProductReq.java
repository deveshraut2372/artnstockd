package com.zplus.ArtnStockMongoDB.dto.req;

import lombok.Data;

@Data
public class AddAdminArtProductReq {

    private String fileManagerId;
    private String adminArtProductId;


}
