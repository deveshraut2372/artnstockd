package com.zplus.ArtnStockMongoDB.dto.res;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReferralEarningMailResponse {
    private String msg;
    private Boolean flag;
}
