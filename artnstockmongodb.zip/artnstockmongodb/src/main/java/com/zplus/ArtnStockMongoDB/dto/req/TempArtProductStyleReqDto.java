package com.zplus.ArtnStockMongoDB.dto.req;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TempArtProductStyleReqDto {

    private String productStyleId;

    private String styleName;

    private String styleImage;

    private String productSubSubCategoryId;

    private String productId;


}
