package com.zplus.ArtnStockMongoDB.dto.req;

import lombok.Data;

@Data
public class ContributerMarkupRes {

    private Double  markup;

    private Double sellingPrince;

    private Double basicPrice;


}
